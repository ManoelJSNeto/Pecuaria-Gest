<?php
// Stats for reports
$totalAnimais = $db->query("SELECT COUNT(*) FROM animais")->fetchColumn();
$totalAtivos  = $db->query("SELECT COUNT(*) FROM animais WHERE status='ativo'")->fetchColumn();
$totalVendidos= $db->query("SELECT COUNT(*) FROM animais WHERE status='vendido'")->fetchColumn();
$totalMortos  = $db->query("SELECT COUNT(*) FROM animais WHERE status='morto'")->fetchColumn();
$totalPesagens= $db->query("SELECT COUNT(*) FROM pesagens")->fetchColumn();
$totalSaude   = $db->query("SELECT COUNT(*) FROM saude")->fetchColumn();
$pesoMedio    = $db->query("SELECT AVG(p.peso) FROM pesagens p INNER JOIN (SELECT animal_id, MAX(data) as md FROM pesagens GROUP BY animal_id) lp ON p.animal_id=lp.animal_id AND p.data=lp.md")->fetchColumn();

// By race
$porRaca = $db->query("SELECT raca, COUNT(*) as total, AVG(peso_inicial) as peso_medio FROM animais GROUP BY raca ORDER BY total DESC")->fetchAll();

// By pasture
$porPasto = $db->query("
  SELECT p.nome, COUNT(a.id) as total, p.capacidade, p.area_ha
  FROM pastagens p LEFT JOIN animais a ON a.pasto_id=p.id AND a.status NOT IN('vendido','morto')
  GROUP BY p.id ORDER BY total DESC
")->fetchAll();

// Monthly pesagens
$pesagensMes = $db->query("
  SELECT strftime('%Y-%m', data) as mes, COUNT(*) as total, AVG(peso) as media
  FROM pesagens WHERE data >= date('now','-12 months')
  GROUP BY mes ORDER BY mes
")->fetchAll();

// Top weight gainers
$topGanho = $db->query("
  SELECT a.brinco, a.nome, a.raca,
    MIN(pe.peso) as peso_min, MAX(pe.peso) as peso_max,
    (MAX(pe.peso)-MIN(pe.peso)) as ganho
  FROM pesagens pe JOIN animais a ON pe.animal_id=a.id
  GROUP BY pe.animal_id HAVING COUNT(*) >= 2
  ORDER BY ganho DESC LIMIT 10
")->fetchAll();

// Saúde por tipo
$saudeTipo = $db->query("SELECT tipo, COUNT(*) as total FROM saude GROUP BY tipo ORDER BY total DESC")->fetchAll();
?>

<div class="row g-3 mb-4">
  <div class="col-md-3">
    <div class="stat-card">
      <div class="stat-icon" style="background:#e8f5ee">🐄</div>
      <div>
        <div class="stat-value"><?= $totalAnimais ?></div>
        <div class="stat-label">Total Cadastrados</div>
        <div class="stat-sub"><?= $totalAtivos ?> ativos • <?= $totalVendidos ?> vendidos</div>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="stat-card">
      <div class="stat-icon" style="background:#e8f5ee">⚖️</div>
      <div>
        <div class="stat-value"><?= $pesoMedio ? number_format($pesoMedio,0) : '—' ?></div>
        <div class="stat-label">Peso Médio Atual (kg)</div>
        <div class="stat-sub"><?= $totalPesagens ?> pesagens registradas</div>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="stat-card">
      <div class="stat-icon" style="background:#fff3cd">⚕️</div>
      <div>
        <div class="stat-value"><?= $totalSaude ?></div>
        <div class="stat-label">Eventos de Saúde</div>
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="stat-card">
      <div class="stat-icon" style="background:#ffe5e5">⚠️</div>
      <div>
        <div class="stat-value"><?= $totalMortos ?></div>
        <div class="stat-label">Mortalidade Total</div>
        <div class="stat-sub"><?= $totalAnimais > 0 ? number_format($totalMortos/$totalAnimais*100,1) : 0 ?>%</div>
      </div>
    </div>
  </div>
</div>

<div class="row g-3 mb-3">
  <!-- Por Raça -->
  <div class="col-lg-6">
    <div class="card">
      <div class="card-header"><i class="bi bi-bar-chart text-primary"></i><h6>Rebanho por Raça</h6></div>
      <div class="card-body p-0">
        <table class="table table-sm mb-0">
          <thead><tr><th>Raça</th><th>Total</th><th>%</th><th>Peso Médio Inicial</th></tr></thead>
          <tbody>
            <?php foreach ($porRaca as $r): ?>
            <tr>
              <td class="fw-600 small"><?= e($r['raca'] ?? 'Não informada') ?></td>
              <td><?= $r['total'] ?></td>
              <td class="text-muted small"><?= $totalAnimais > 0 ? number_format($r['total']/$totalAnimais*100,1).'%' : '—' ?></td>
              <td class="small"><?= $r['peso_medio'] ? number_format($r['peso_medio'],1).' kg' : '—' ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Por Pastagem -->
  <div class="col-lg-6">
    <div class="card">
      <div class="card-header"><i class="bi bi-tree text-success"></i><h6>Ocupação por Pastagem</h6></div>
      <div class="card-body p-0">
        <table class="table table-sm mb-0">
          <thead><tr><th>Pastagem</th><th>Animais</th><th>Cap.</th><th>Ocupação</th></tr></thead>
          <tbody>
            <?php foreach ($porPasto as $pp): ?>
            <?php $oc = $pp['capacidade'] > 0 ? min(100, round($pp['total']/$pp['capacidade']*100)) : 0; ?>
            <tr>
              <td class="small fw-600"><?= e($pp['nome']) ?></td>
              <td><?= $pp['total'] ?></td>
              <td class="text-muted small"><?= $pp['capacidade'] ?? '—' ?></td>
              <td style="min-width:100px">
                <div class="progress" style="height:6px">
                  <div class="progress-bar bg-<?= $oc>=90?'danger':($oc>=70?'warning':'success') ?>" style="width:<?= $oc ?>%"></div>
                </div>
                <small class="text-muted"><?= $oc ?>%</small>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<div class="row g-3">
  <!-- Top ganho de peso -->
  <div class="col-lg-7">
    <div class="card">
      <div class="card-header justify-content-between">
        <div class="d-flex align-items-center gap-2">
          <i class="bi bi-trophy text-warning"></i><h6>Top 10 — Maior Ganho de Peso</h6>
        </div>
        <a href="/relatorios?export=ganho" class="btn btn-sm btn-outline-secondary">
          <i class="bi bi-download me-1"></i>Exportar
        </a>
      </div>
      <div class="card-body p-0">
        <table class="table table-sm mb-0">
          <thead><tr><th>#</th><th>Animal</th><th>Raça</th><th>Peso Mín.</th><th>Peso Máx.</th><th>Ganho</th></tr></thead>
          <tbody>
            <?php foreach ($topGanho as $i => $g): ?>
            <tr>
              <td class="text-muted small"><?= $i+1 ?>º</td>
              <td><a href="/animais" class="fw-600 text-decoration-none" style="color:#1a4d2e"><?= e($g['brinco']) ?></a><br><small class="text-muted"><?= e($g['nome'] ?? '') ?></small></td>
              <td class="small text-muted"><?= e($g['raca'] ?? '—') ?></td>
              <td class="small"><?= number_format($g['peso_min'],1) ?> kg</td>
              <td class="small"><?= number_format($g['peso_max'],1) ?> kg</td>
              <td class="fw-700 text-success">+<?= number_format($g['ganho'],1) ?> kg</td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Saúde por tipo -->
  <div class="col-lg-5">
    <div class="card">
      <div class="card-header"><i class="bi bi-heart-pulse text-danger"></i><h6>Eventos de Saúde por Tipo</h6></div>
      <div class="card-body p-0">
        <table class="table table-sm mb-0">
          <thead><tr><th>Tipo</th><th>Registros</th><th>%</th></tr></thead>
          <tbody>
            <?php foreach ($saudeTipo as $st): ?>
            <tr>
              <td class="small fw-600"><?= e($st['tipo']) ?></td>
              <td><?= $st['total'] ?></td>
              <td class="text-muted small"><?= $totalSaude > 0 ? number_format($st['total']/$totalSaude*100,1).'%' : '—' ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="card mt-3">
      <div class="card-header"><i class="bi bi-printer text-secondary"></i><h6>Exportar Relatórios</h6></div>
      <div class="card-body">
        <div class="d-grid gap-2">
          <a href="/relatorios?export=animais" class="btn btn-outline-primary btn-sm">
            <i class="bi bi-download me-1"></i> Relatório Completo de Animais
          </a>
          <a href="/relatorios?export=saude" class="btn btn-outline-danger btn-sm">
            <i class="bi bi-download me-1"></i> Relatório de Saúde
          </a>
          <a href="/relatorios?export=pesagens" class="btn btn-outline-success btn-sm">
            <i class="bi bi-download me-1"></i> Relatório de Pesagens
          </a>
          <button onclick="window.print()" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-printer me-1"></i> Imprimir esta página
          </button>
        </div>
      </div>
    </div>
  </div>
</div>
