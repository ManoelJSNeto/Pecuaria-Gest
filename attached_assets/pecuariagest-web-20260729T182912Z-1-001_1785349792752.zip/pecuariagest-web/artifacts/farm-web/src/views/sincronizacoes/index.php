<?php
$sincs = $db->query("SELECT * FROM sincronizacoes ORDER BY created_at DESC LIMIT 50")->fetchAll();
$totalSincs = $db->query("SELECT COUNT(*) FROM sincronizacoes")->fetchColumn();
$ultimaSync = $db->query("SELECT MAX(created_at) FROM sincronizacoes")->fetchColumn();
$totalDados = $db->query("SELECT SUM(dados_recebidos) FROM sincronizacoes")->fetchColumn();
?>

<div class="row g-3 mb-4">
  <div class="col-md-4">
    <div class="stat-card">
      <div class="stat-icon" style="background:#e3f2fd">📱</div>
      <div>
        <div class="stat-value"><?= $totalSincs ?></div>
        <div class="stat-label">Sincronizações</div>
        <div class="stat-sub">Última: <?= $ultimaSync ? formatDateTime($ultimaSync) : '—' ?></div>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="stat-card">
      <div class="stat-icon" style="background:#e8f5ee">📊</div>
      <div>
        <div class="stat-value"><?= $totalDados ?? 0 ?></div>
        <div class="stat-label">Registros Recebidos</div>
        <div class="stat-sub">Via app mobile</div>
      </div>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card p-3">
      <div class="info-label mb-2">Endpoint da API Mobile</div>
      <code class="d-block p-2 bg-light rounded small">POST /api/sync</code>
      <div class="info-label mt-2 mb-1">Autenticação</div>
      <code class="small bg-light p-1 rounded d-block">X-API-Key: pecuaria-mobile-key</code>
      <a href="#api-docs" class="btn btn-sm btn-outline-primary mt-2">Ver documentação</a>
    </div>
  </div>
</div>

<div class="card mb-4">
  <div class="card-header"><i class="bi bi-clock-history text-primary"></i><h6>Histórico de Sincronizações</h6></div>
  <div class="card-body p-0">
    <table class="table table-hover mb-0">
      <thead><tr><th>Data/Hora</th><th>Dispositivo</th><th>IP</th><th>Dados</th><th>Status</th><th>Detalhes</th></tr></thead>
      <tbody>
        <?php if (empty($sincs)): ?>
          <tr><td colspan="6" class="text-center text-muted py-4">
            Nenhuma sincronização registrada ainda.<br>
            <small>Aguardando dados do aplicativo mobile.</small>
          </td></tr>
        <?php endif; ?>
        <?php foreach ($sincs as $s): ?>
        <tr>
          <td class="small"><?= formatDateTime($s['created_at']) ?></td>
          <td class="small fw-600"><?= e($s['dispositivo'] ?? '—') ?></td>
          <td class="small text-muted"><?= e($s['ip'] ?? '—') ?></td>
          <td class="small"><?= $s['dados_recebidos'] ?> registros</td>
          <td><span class="badge bg-<?= $s['status']==='ok'?'success':'danger' ?>"><?= e($s['status']) ?></span></td>
          <td class="small text-muted"><?= e($s['detalhes'] ?? '—') ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- API Docs -->
<div class="card" id="api-docs">
  <div class="card-header"><i class="bi bi-code-square text-success"></i><h6>Documentação da API para Mobile</h6></div>
  <div class="card-body">
    <h6 class="fw-700">POST /api/sync</h6>
    <p class="text-muted small mb-3">Endpoint para envio de dados do aplicativo mobile para o servidor.</p>

    <div class="mb-3">
      <div class="info-label mb-1">Headers obrigatórios</div>
      <pre class="bg-light p-3 rounded small">Content-Type: application/json
X-API-Key: pecuaria-mobile-key</pre>
    </div>

    <div class="mb-3">
      <div class="info-label mb-1">Body (JSON)</div>
      <pre class="bg-light p-3 rounded small">{
  "dispositivo": "Samsung Galaxy S22",
  "pesagens": [
    {
      "brinco": "BR0001",
      "peso": 380.5,
      "data": "2026-07-28",
      "observacao": "Pesagem de rotina"
    }
  ],
  "saude": [
    {
      "brinco": "BR0003",
      "tipo": "Vacinação",
      "descricao": "Vacina aftosa",
      "data": "2026-07-28",
      "medicamento": "Aftosa"
    }
  ],
  "animais_novos": [
    {
      "brinco": "BR0099",
      "sexo": "F",
      "raca": "Nelore",
      "data_nascimento": "2024-03-15"
    }
  ]
}</pre>
    </div>

    <div class="mb-3">
      <div class="info-label mb-1">Resposta de sucesso (200)</div>
      <pre class="bg-light p-3 rounded small">{
  "status": "ok",
  "processados": {
    "pesagens": 1,
    "saude": 1,
    "animais_novos": 1
  },
  "erros": []
}</pre>
    </div>

    <div class="alert alert-info small mb-0">
      <i class="bi bi-info-circle me-1"></i>
      O campo <code>brinco</code> é usado para identificar o animal. Se um brinco não existir no sistema, ele será ignorado (exceto para <code>animais_novos</code>).
    </div>
  </div>
</div>
