<?php
$animais = $db->query("SELECT id, brinco, nome, sexo FROM animais WHERE status NOT IN ('vendido','morto') ORDER BY brinco")->fetchAll();
$preAnimal = $_GET['animal_id'] ?? null;
?>

<div class="mb-3">
  <a href="/reproducao" class="btn btn-sm btn-outline-secondary">
    <i class="bi bi-arrow-left me-1"></i> Voltar
  </a>
</div>

<div class="row justify-content-center">
  <div class="col-lg-6">
    <div class="form-section">
      <div class="form-section-title"><i class="bi bi-diagram-3 text-info"></i> Registrar Evento Reprodutivo</div>
      <form method="POST" action="/reproducao/salvar">
        <?= csrf_field() ?>
        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label">Animal *</label>
            <select name="animal_id" class="form-select" required>
              <option value="">— Selecione —</option>
              <?php foreach ($animais as $a): ?>
                <option value="<?= $a['id'] ?>" <?= $preAnimal==$a['id']?'selected':'' ?>>
                  <?= e($a['brinco']) ?> (<?= $a['sexo']==='F'?'♀ Fêmea':'♂ Macho' ?>)<?= $a['nome']?' — '.e($a['nome']):'' ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label">Tipo de Evento *</label>
            <select name="tipo" class="form-select" required>
              <option value="">— Selecione —</option>
              <?php foreach (['Inseminação Artificial','Cobertura Natural','Diagnóstico de Gestação','Parto','Aborto','Desmame','Outro'] as $t): ?>
                <option value="<?= $t ?>"><?= $t ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="col-md-6">
            <label class="form-label">Data *</label>
            <input type="date" name="data" class="form-control" required value="<?= date('Y-m-d') ?>">
          </div>
          <div class="col-md-6">
            <label class="form-label">Touro / Brinco do Pai</label>
            <input type="text" name="touro_brinco" class="form-control" placeholder="Opcional">
          </div>
          <div class="col-12">
            <label class="form-label">Resultado</label>
            <input type="text" name="resultado" class="form-control" list="resultList"
                   placeholder="Ex: Positivo, Prenha, Gemelar...">
            <datalist id="resultList">
              <option value="Positivo"><option value="Negativo"><option value="Prenha">
              <option value="Nascimento normal"><option value="Nascimento gemelar">
            </datalist>
          </div>
          <div class="col-12">
            <label class="form-label">Observação</label>
            <textarea name="observacao" class="form-control" rows="2" placeholder="Detalhes..."></textarea>
          </div>
          <div class="col-12">
            <div class="d-flex gap-2">
              <button type="submit" class="btn btn-primary flex-grow-1">
                <i class="bi bi-check-lg me-1"></i> Salvar
              </button>
              <a href="/reproducao" class="btn btn-outline-secondary">Cancelar</a>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
