<?php
$alertas = $db->query("
  SELECT al.*, a.brinco, a.nome as animal_nome, a.id as animal_id_ref
  FROM alertas al
  LEFT JOIN animais a ON al.animal_id=a.id
  ORDER BY al.lido ASC, al.created_at DESC
")->fetchAll();

// Mark all as read (if requested)
if (isset($_GET['marcar_todos'])) {
    $db->exec("UPDATE alertas SET lido=1");
    redirect('/alertas');
}
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <div class="text-muted small"><?= count($alertas) ?> alertas no total</div>
  <div class="d-flex gap-2">
    <a href="/alertas/novo" class="btn btn-primary btn-sm">
      <i class="bi bi-plus-lg me-1"></i> Criar Alerta
    </a>
    <a href="/alertas?marcar_todos=1" class="btn btn-outline-secondary btn-sm"
       onclick="return confirm('Marcar todos como lidos?')">
      <i class="bi bi-check-all me-1"></i> Marcar todos como lidos
    </a>
  </div>
</div>

<div class="card">
  <div class="card-body p-0">
    <table class="table table-hover mb-0">
      <thead>
        <tr><th>Animal</th><th>Tipo</th><th>Mensagem</th><th>Data</th><th>Status</th><th>Ações</th></tr>
      </thead>
      <tbody>
        <?php if (empty($alertas)): ?>
          <tr><td colspan="6" class="text-center text-muted py-5">
            <i class="bi bi-check-circle-fill text-success fs-2 d-block mb-2"></i>
            Nenhum alerta registrado.
          </td></tr>
        <?php endif; ?>
        <?php foreach ($alertas as $al): ?>
        <?php
          $tipoIcon = match($al['tipo']) {
            'saude'     => ['bi-heart-pulse-fill','danger'],
            'vacina'    => ['bi-shield-plus','warning'],
            'pesagem'   => ['bi-rulers','info'],
            'reproducao'=> ['bi-diagram-3','info'],
            default     => ['bi-exclamation-circle','secondary'],
          };
        ?>
        <tr class="<?= $al['lido'] ? 'text-muted' : 'fw-500' ?>" style="<?= !$al['lido'] ? 'background:#fafff8' : '' ?>">
          <td>
            <?php if ($al['animal_id_ref']): ?>
              <a href="/animais/<?= $al['animal_id_ref'] ?>" class="text-decoration-none fw-600" style="color:#1a4d2e">
                <?= e($al['brinco'] ?? '—') ?>
              </a>
              <small class="text-muted d-block"><?= e($al['animal_nome'] ?? '') ?></small>
            <?php else: ?>
              <span class="text-muted">—</span>
            <?php endif; ?>
          </td>
          <td><span class="badge bg-<?= $tipoIcon[1] ?>"><i class="bi <?= $tipoIcon[0] ?> me-1"></i><?= e($al['tipo']) ?></span></td>
          <td><?= e($al['mensagem']) ?></td>
          <td class="small text-muted"><?= formatDateTime($al['created_at']) ?></td>
          <td><?= $al['lido'] ? '<span class="badge bg-secondary">Lido</span>' : '<span class="badge bg-danger">Novo</span>' ?></td>
          <td>
            <div class="btn-group btn-group-sm">
              <?php if (!$al['lido']): ?>
              <a href="/alertas/<?= $al['id'] ?>/ler" class="btn btn-outline-success" title="Marcar como lido">
                <i class="bi bi-check-lg"></i>
              </a>
              <?php endif; ?>
              <form method="POST" action="/alertas/<?= $al['id'] ?>/excluir" onsubmit="return confirm('Excluir alerta?')">
                <?= csrf_field() ?><input type="hidden" name="_method" value="DELETE">
                <button class="btn btn-outline-danger"><i class="bi bi-trash"></i></button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
